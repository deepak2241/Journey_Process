from django.utils import timezone

from .models import Stage


class EventProcessor:
    def __init__(self, user_journey):
        self.user_journey = user_journey

    def process_event(self, event_type):

        current_stage = self.user_journey.current_stage
        if current_stage.next_stage is None:
            self.user_journey.completed = True
            stage_obj = Stage.objects.filter(name=event_type).first()
            self.user_journey.current_stage = stage_obj
            self.user_journey.save()
            return
        if current_stage.event_trigger == event_type:
            if self.user_journey.completed:
                return
            stage_obj = Stage.objects.filter(name=event_type).first()
            self.user_journey.current_stage = stage_obj
            self.user_journey.save()
            self.perform_action()

    def perform_action(self):
        stage = self.user_journey.current_stage

        if stage.action_type == 'email':
            self.send_email()

        elif stage.action_type == 'whatsapp':
            self.send_whatsapp()

    def send_email(self):
        print(f"Sending email to user {self.user_journey.user_email}")

    def send_whatsapp(self):
        print(f"Sending WhatsApp message to user {self.user_journey.user_email}")

    def check_timeout(self):
        # This function checks if the wait time has passed and if so, triggers the next action
        current_time = timezone.now()
        if self.user_journey.updated_at + self.user_journey.current_stage.wait_time <= current_time:
            if self.user_journey.current_stage.name == 'Email':
                self.process_event('Whatsapp')
            elif self.user_journey.current_stage.name == 'Whatsapp':
                self.process_event('Negative List')
        elif self.user_journey.current_stage.name == 'Whatsapp':
            self.process_event('Positive List')
        else:
            self.process_event('CRM')
