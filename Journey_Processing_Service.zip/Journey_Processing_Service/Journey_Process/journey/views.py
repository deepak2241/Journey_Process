from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Journey, UserJourney
from .serializers import JourneySerializer, UserJourneySerializer
from .utils import EventProcessor


class JourneyListView(APIView):
    def get(self, request):
        journeys = Journey.objects.all()
        serializer = JourneySerializer(journeys, many=True)
        return Response(serializer.data)


class StartJourneyView(APIView):
    def post(self, request):
        email_id = request.data.get('email')
        journey_id = request.data.get('journey_id')

        try:
            journey = Journey.objects.get(id=journey_id)
            first_stage = journey.stages.first()

            user_journey = UserJourney.objects.create(user_email=email_id, journey=journey, current_stage=first_stage)
            processor = EventProcessor(user_journey)
            processor.perform_action()

            return Response({"status": "success", "message": "Journey action been taken."}, status=status.HTTP_201_CREATED)
        except Journey.DoesNotExist:
            return Response({"error": "Journey not found."}, status=status.HTTP_404_NOT_FOUND)


class TriggerEventView(APIView):
    def post(self, request, user_journey_id):
        try:
            user_journey = UserJourney.objects.get(id=user_journey_id)
            EventProcessor(user_journey).check_timeout()
            return Response({"status": "success", "message": "Event processed."})
        except UserJourney.DoesNotExist:
            return Response({"error": "User journey not found."}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class UserJourneyStatusView(APIView):
    def get(self, request, user_journey_id):
        try:
            user_journey = UserJourney.objects.get(id=user_journey_id)
            serializer = UserJourneySerializer(user_journey)
            return Response(serializer.data)
        except UserJourney.DoesNotExist:
            return Response({"error": "User journey not found."}, status=status.HTTP_404_NOT_FOUND)
