from rest_framework import serializers
from .models import Journey, Stage, UserJourney


class JourneySerializer(serializers.ModelSerializer):
    class Meta:
        model = Journey
        fields = '__all__'


class StageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Stage
        fields = '__all__'


class UserJourneySerializer(serializers.ModelSerializer):
    class Meta:
        model = UserJourney
        fields = '__all__'
