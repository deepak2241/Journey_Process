from django.urls import path
from .views import JourneyListView, StartJourneyView, TriggerEventView, UserJourneyStatusView

urlpatterns = [
    path('journeys/', JourneyListView.as_view(), name='journey-list'),
    path('start-journey/', StartJourneyView.as_view(), name='start-journey'),
    path('trigger-event/<int:user_journey_id>/', TriggerEventView.as_view(), name='trigger-event'),
    path('user-journey/<int:user_journey_id>/', UserJourneyStatusView.as_view(), name='user-journey-status'),
]
