from django.db import models


class Journey(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name


class Stage(models.Model):
    journey = models.ForeignKey(Journey, on_delete=models.CASCADE, related_name='stages')
    name = models.CharField(max_length=255)
    action_type = models.CharField(max_length=50, choices=[('email', 'Send Email'), ('whatsapp', 'Send WhatsApp'),
                                                           ('update_crm', 'Update CRM')])
    wait_time = models.DurationField(null=True, blank=True)
    next_stage = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='previous_stage')
    event_trigger = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return self.name


class UserJourney(models.Model):
    user_email = models.EmailField()
    current_stage = models.ForeignKey(Stage, on_delete=models.SET_NULL, null=True)
    journey = models.ForeignKey(Journey, on_delete=models.CASCADE)
    started_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed = models.BooleanField(default=False)

    def __str__(self):
        return self.user_email
