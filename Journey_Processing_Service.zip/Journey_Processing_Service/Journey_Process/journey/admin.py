from django.contrib import admin

from .models import Journey, UserJourney, Stage

# Register your models here.
admin.site.register(Journey)
admin.site.register(UserJourney)
admin.site.register(Stage)